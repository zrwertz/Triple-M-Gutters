import React from 'react';

function App() {
  return (
    <main style={{ minHeight: '100vh', background: '#e0f2fe', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
      <div style={{ background: 'white', borderRadius: '1.5rem', boxShadow: '0 10px 36px rgba(0,0,0,0.1)', maxWidth: '600px', width: '100%', padding: '2.5rem', textAlign: 'center' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a' }}>Rain or Shine, We’ve Got You Covered!</h1>
        <p style={{ fontSize: '1.25rem', color: '#2563eb', margin: '16px 0' }}>Seamless Gutter Installation & Repair in Central Arkansas</p>
        <a href="mailto:info@triplemgutters.com" style={{ display: 'inline-block', marginTop: '20px', padding: '12px 24px', backgroundColor: '#2563eb', color: '#fff', borderRadius: '8px', textDecoration: 'none', fontWeight: 'bold' }}>Request a Free Estimate</a>
        <div style={{ marginTop: '30px', color: '#1e3a8a' }}>
          <p><strong>📞 Call Today:</strong> <a href="tel:5015551234">(501) 555-1234</a></p>
          <p><strong>📧 Email:</strong> <a href="mailto:info@triplemgutters.com">info@triplemgutters.com</a></p>
        </div>
      </div>
    </main>
  );
}

export default App;